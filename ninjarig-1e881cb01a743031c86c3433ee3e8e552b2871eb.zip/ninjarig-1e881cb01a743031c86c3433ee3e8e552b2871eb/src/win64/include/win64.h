//
// Created by Haifa Bogdan Adnan on 13/08/2018.
//

#ifndef WIN64_COMPATIBILITY_LAYER_H
#define WIN64_COMPATIBILITY_LAYER_H

//#include <windows.h>
#include <WinSock2.h>
#include <WS2tcpip.h>

#endif //WIN64_COMPATIBILITY_LAYER_H
