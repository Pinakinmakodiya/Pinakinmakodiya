//
// Created by Haifa Bogdan Adnan on 06/08/2018.
//

#ifndef ARGON2_OPENCL_KERNEL_H
#define ARGON2_OPENCL_KERNEL_H

extern string OpenCLKernel;

#endif //ARGON2_OPENCL_KERNEL_H
